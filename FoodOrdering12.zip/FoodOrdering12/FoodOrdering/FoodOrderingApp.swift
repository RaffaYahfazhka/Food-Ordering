//
//  FoodOrderingApp.swift
//  FoodOrdering
//
//  Created by Rafi Sakhi 01/03/21.
//

import SwiftUI
import Firebase
import FirebaseCore

@main
struct FoodOrderingApp: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self)var delegate
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//initaillizing firebase

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        
        FirebaseApp.configure()
        return true
      }
}
